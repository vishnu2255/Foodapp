<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class chef_dishes extends Model
{
    //
}
