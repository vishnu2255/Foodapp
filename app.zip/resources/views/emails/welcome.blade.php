<html>
    <body>
        <h1>
            Welcome!! {{$user->name}}

            
        </h1>
    </body>
</html>