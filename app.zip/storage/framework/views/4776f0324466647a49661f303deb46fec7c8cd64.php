<?php $__env->startSection('content'); ?>


<?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    <h3>Order placed</h3>
    </div>
<?php endif; ?>


<?php if($curentorder->count()>0): ?>


<div class="container">

    <div class="row">
        <div class="col-md-8 col-md-offset-2">

            <h2>My Current Order </h2>

            <div class="panel panel-default">
                <div class="panel-body">

                    <ul class="list-group">

<?php $itms = unserialize($curentorder[0]->cart) ; $itmid=0; ?>
<?php $__currentLoopData = $itms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<li class="list-group-item">
<?php $itmid++; ?>
<div class="row">
    <div class="col-sm-3">
            <span>Item No. <?php echo e($itmid); ?></span>
    </div>
    <div class="col-sm-3">
            <span class="ml-10"> <?php echo e($itm->itm_name); ?> </span>
    </div>
    <div class="col-sm-3">
            <span class="ml-10"> Units <?php echo e($itm->qty); ?> </span>
    </div>
    <div class="col-sm-3">
            Price <span class="badge">  $<?php echo e($itm->itm_price); ?> </span>
    </div>
    
</div>

</li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </div>
                <div class="panel-default mt-5 pull-right">
                    <strong>Total Price : <?php echo e($curentorder[0]->totalamnt); ?></strong>
                </div>    
            </div>

        </div>
    </div>


</div>
<?php endif; ?>
<?php if($oldorders->count()>0): ?>
<div class="container" style="margin-top: 50px; margin-bottom: 25px" >
<div class="row">
        <div class="col-md-8 col-md-offset-2">

            <h2 class="mb-50" style="margin-bottom: 50px">My Previous Orders </h2>

            <div class="panel panel-default">
                
                    


<?php $__currentLoopData = $oldorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="panel-body mb-3" >
<h4>Chef <?php echo e($ord->name); ?></h4>
<ul class="list-group">
         <li class="list-group-item">
         <span>OrderNum  #<?php echo e($ord->id); ?></span>
         <span class="ml-5"><?php echo e(date($ord->created_date)); ?></span>
         <span class="pull-right"> <strong>Total Price : <?php echo e($ord->totalamnt); ?></strong> </span>
         
         </li>
</ul>

  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
            </div>

        </div>
    </div>


</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>