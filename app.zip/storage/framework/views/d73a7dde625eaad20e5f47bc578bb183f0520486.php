<?php $__env->startSection('content'); ?>






<div class="col-md-10 order-md-2 mb-4" style="margin: 20px">
    <h4 class="d-flex justify-content-between align-items-center mb-3" style="text-align: center">
      
      Your Cart
       
    </h4>
<?php $chefcnt=0;?>
    <?php $__currentLoopData = $chefcarts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php 
       $chefcnt++;
       $chefdet = explode('_',$key);
       $chefid = $chefdet[0];
       $chefname = $chefdet[1];
       $totsum = $chefdet[2];
?>
<div class="row" style="margin-top: 20px">
    <div class="col-md-10 col-sm-10">
            <h4 >
                    <a href="/chefs/<?php echo e($chefid); ?>" style="font-family: georgia,serif"> <b> <?php echo e($chefname); ?> </b> </a>    
            </h4>
    </div>

    <div class="col-md-2 col-sm-2">
       
    
        

    </div>
        
</div>
    

    <div class="row">

        <div class="col-md-8">

    <table class="table table-striped" style="margin: 20px">
        <thead>
          <tr>
            <th scope="col">SNo</th>
            <th scope="col">Product Name</th>
            <th scope="col">Quantity</th>
            <th scope="col">Price</th>
          </tr>
        </thead>
        <tbody>
          <?php $id=0; ?>
          <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <?php $id++;?>
          <th scope="row"><?php echo e($id); ?></th>
            <td>
                <h6 class="my-0"><?php echo e($cartitem->itm_name); ?></h6>
                <small class="text-muted"><?php echo e($cartitem->itm_desc); ?></small>
            </td>
            <td>
              
              
              <input type="number" id="<?php echo e($cartitem->menu_item_id.'_'.$cartitem->chef_id); ?>" class="form-control btnquantitycart" name="quantity" min="1" max="10" value="<?php echo e($cartitem->qty); ?>" style="text-align: center;width: 70px">
              
              
            </td>
            <td><?php echo e($cartitem->itm_price); ?></td>

            <td>
            <button type="button" id="rem_<?php echo e($cartitem->menu_item_id); ?>" class="btn btn-danger btn-sm removebtn" aria-label="Left Align">
                          Remove
                    </button>
            </td>
          </tr>
          
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
         
        </tbody>
      </table>

                  
    </div>


<div class="col-md-4" id="drinks_<?php echo e($chefid); ?>" style="display:none">
        
        <?php 
        $drsec = $value[0]->drinks;
        $dr = json_decode($drsec); 
        $did=0;           
        ?>

<table class="table table-hover" style="margin: 20px">
        <thead>
          <tr>
            <th scope="col">SNo</th>
            <th scope="col">Drink</th>
            <th scope="col">Quantity</th>
            <th scope="col">Price</th>
          </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $dr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dname=>$dvalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
        <?php  $did++; ?>
<th scope="row">
<?php echo e($did); ?>

</th>
<td> <?php echo e($dname); ?> </td>
<td>


<input type="number" id="<?php echo e($chefid); ?>" class="form-control drinksquantitycart" name="drnkquantity" min="1" max="10" value="<?php echo e($dvalue->qty); ?>" style="text-align: center;width:70px;">

</td>


<td> <?php echo e($dvalue->price); ?> </td>

</tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
</table>

    </div>
</div>
      <div class="row" style="margin: 20px">
          <div class="col-md-6">
                <a href="/checkout/<?php echo e($chefid); ?>"  class="btn btn-success btn-lg" style="float: left" id="checkout_<?php echo e($chefid); ?>" >Proceed to Checkout</a>            
          </div>
    
          
          <div class="col-md-4" style="float:right">
               <span style="font-family: georgia,serif">Total:  </span> <span class="" style=""> $ </span> <span id="tot_<?php echo e($chefid); ?>"> <?php echo e($totsum); ?></span>   
          </div>


         
      </div>

    
   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>