<html>
    <body>
        <h1>
            Welcome!! <?php echo e($user->name); ?>


            
        </h1>
    </body>
</html>