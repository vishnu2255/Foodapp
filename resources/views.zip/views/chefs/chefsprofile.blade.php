@include('inc.header')
<div class="row featurette" style="background-color:#fb7a69">
      
        <div class="container marketing" style=" color:#fff">
          <div class="col-md-7">
             <br>
  <br>
  <br>
  <br>
   <h2 class="featurette-heading">Home cooked food without the stress</h2>
           <p class="alead">Vestibulum volutpat non nulla at efficitur. Cras pretium, lacus in volutpat tempus, purus massa venenatis diam, eu</p>
           
          </div>
         
          <div class="col-md-5"><br><br><br><br><br>
            <img src="img/plate.png" width="100%" height="100%" alt="i love takeout app IOS"><br><br><br>
          </div>
          </div>
        </div>
  <br><br>
  <div class="container marketing">
  
        <div class="row featurette">
          <div class="col-md-8 col-md-push-4" style="text-align:center">
          <br><br><br><br><br><br>
    <table class="table table-striped" width="100%" border="0">
      <tr>
        <td width="27%">Location:</td>
        <td width="73%"> Toronto On</td>
      </tr>
      <tr>
        <td>Orders:</td>
        <td>3423</td>
      </tr>
      <tr>
        <td>Certificates: </td>
        <td>George Brown </td>
      </tr>
    </table>
    <br><br>
    <a href="Listings.php" class="btn btn-warning btn-lg active" role="button">Back to Menu</a>
  
          </div>
          <div class="col-md-4 col-md-pull-8">
      
            <img src="img/chef2.jpg" class="img-circle" />
            <h2>Samantha Singh</h2>
            <p class="lead">Orders: 343 &nbsp;&nbsp; <img src="img/stars.png" width="50%" height="50%" /></p>
           
        </div>
  
        </div>
     <hr/>        
@include('inc.footer')