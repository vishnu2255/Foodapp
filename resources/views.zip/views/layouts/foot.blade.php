
<div style="background-color:#e77748">

<div class="container" >
    <div class="row">
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
        <div class="row">

        <nav class="col-xs-12">

            <ul class="list-inline">
                <li class="list-inline-item"> <a class="well-flat" href="">ABOUT</a></li>
                <li class="list-inline-item"> <a class="text-dark" href="">PRIVACY</a></li>
                <li class="list-inline-item"> <a class="list-container" href="">TERMS</a></li>
                <li class="list-inline-item"> <a class="list-content" href="">FAQ</a></li>
                <li class="list-inline-item"> <a href="">CONTACT US</a></li>                
            </ul>

        </nav>

    </div>
    <div class="row">
            <nav class="col-xs-12" style="text-align: center">

                    <ul class="list-inline">
                       
                           <li class="list-inline-item"> <a href=""> <ion-icon style="font-size:36px;color: blue" name="logo-facebook"></ion-icon> </a>  </li>   
                           <li class="list-inline-item"> <a href=""> <ion-icon style="font-size:36px; color: red" name="logo-googleplus"></ion-icon> </a>  </li>
                           <li class="list-inline-item"> <a href=""> <ion-icon style="font-size:36px;color: lightblue " name="logo-twitter"></ion-icon> </a>  </li>        
                    </ul>
        
                </nav>
            </div>
                <div class="col-md-4">
                        <script type="text/javascript" src="https://cdn.ywxi.net/js/1.js" async></script>
                    </div>
    </div>
</div>

</div>