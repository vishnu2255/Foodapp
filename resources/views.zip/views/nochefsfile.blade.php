@extends('layouts.app')

@section('content')

<div class="container" style="height: 400px;">

    <h1 style="margin: 75px;" class="text-muted">
        Unfortunately,We are not available in your area!!        
    </h1>

    <h1 style="margin: 75px;" class="text-muted">    
            Please Check back Soon!!
    </h1>

</div>

@endsection
