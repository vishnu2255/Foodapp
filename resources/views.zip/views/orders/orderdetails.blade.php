@include('inc.header')

<div class="row featurette" style="background-color:#fb7a69">
      
     
        <div class="col-md-7">
           <br>
<br>
 <h2 class="featurette-heading" align="center" style="color:#FFF">Order Checkout </h2>
       
         
        </div>
        </div>
        </div>
        
<div class="container" align="center"><br><br><br>

 <div class="item" style="width:360px">
    <div class="pad15" > <a href="profile1.php"><img src="img/fooda.jpg" width="100%"/></a> 
                      <div class="row">
  <div class="col-md-8" style="text-align: left; color:#fb7a69"><h2>Burger</h2></div>
  <div class="col-md-4">
    <h2> $12</h2></div>
</div>
<hr/><br><br>
  <table class="table table-striped" width="40%" border="0">
    <tr>
      <td>Location:</td>
      <td>3220 Dufferin St.</td>
    </tr>
    <tr>
      <td>Quantity:</td>
      <td><select name="cars">
  <option value="volvo">1</option>
  <option value="saab">2</option>
  <option value="fiat">3</option>
  <option value="audi">4</option>
</select></td>
    </tr>
    <tr>
      <td>Certificates: </td>
      <td>George Brown </td>
    </tr>
  </table>
  <p>Add drinks</p>
  <table class="table table-striped" width="40%" border="0">
   <tr>
      <td>Type:</td>
      <td><select name="cars">
  <option value="volvo">Sprite</option>
  <option value="saab">Coke</option>
  <option value="fiat">Ice Tea</option>
  <option value="audi">Orange </option>
</select></td>
    </tr>
    <tr>
      <td>Quantity:</td>
      <td><select name="cars">
  <option value="volvo">1</option>
  <option value="saab">2</option>
  <option value="fiat">3</option>
  <option value="audi">4</option>
</select></td>
    </tr>
  </table>
  <p><br>
    </p>
  <table class="table table-striped" width="40%" border="0">
    <tr>
      <td width="52%"><strong>Tax:</strong></td>
      <td width="48%">&nbsp;</td>
    </tr>
    <tr>
      <td><strong>Total:</strong></td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <br><button type="button" class="btn btn-success btn-lg active">Prcess Order</button>

  <p><br>
  </p>
      </div>




@include('inc.footer')

