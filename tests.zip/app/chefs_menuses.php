<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class chefs_menuses extends Model
{
    //
}
