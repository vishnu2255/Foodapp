<?php $__env->startSection('content'); ?>


<?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    <h3>Order placed</h3>
   
    </div>
<?php endif; ?>
<div class="container">

<h2>My Current Orders </h2>
<span>Status </span><span id="statusorder">Pending</span> 
<div class="row">

    <div class="col-md-8">
            <?php if($curentorder->count()>0): ?>

            <?php $__currentLoopData = $curentorder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
     <span> <h3>OrderNum #<?php echo e($order->id); ?></h3> 
     
     </span>
<div class="container">
        

    <div class="row">
        <div class="col-md-10 col-md-offset-2">

           
            <div class="panel panel-default">
                <div class="panel-body">

                    <ul class="list-group">

<?php $itms = unserialize($order->cart) ; $itmid=0; ?>
<?php $__currentLoopData = $itms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<li class="list-group-item">
<?php $itmid++; ?>
<div class="row">
    <div class="col-sm-3">
            <span>Item No. <?php echo e($itmid); ?></span>
    </div>
    <div class="col-sm-3">
            <span class="ml-10"> <?php echo e($itm->itm_name); ?> </span>
    </div>
    <div class="col-sm-3">
            <span class="ml-10"> Units <?php echo e($itm->qty); ?> </span>
    </div>
    <div class="col-sm-3">
        <strong>  Price <span class="">  $<?php echo e($itm->itm_price); ?> </span> </strong>
    </div>
    
</div>

</li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $drinks = unserialize($order->drnkscart) ; $itmid=0; ?>


<?php if($drinks!=null && $drinks->count()>0): ?>
<h3 class="mb-3 mt-3">Drinks</h3>
<?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<li class="list-group-item">
<?php $itmid++; ?>
<div class="row">
    <div class="col-sm-3">
            <span>Item No. <?php echo e($itmid); ?></span>
    </div>
    <div class="col-sm-3">
            <span class="ml-10"> <?php echo e($drink->drnk_name); ?> </span>
    </div>
    <div class="col-sm-3">
            <span class="ml-10"> Units <?php echo e($drink->drnkqty); ?> </span>
    </div>
    <div class="col-sm-3">
          <strong> Price <span class="ml-10">  $<?php echo e($drink->drnk_price); ?> </span> </strong>
    </div>
    
</div>

</li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

                    </ul>

                </div>
                <div class="panel-default mt-5 pull-right">
                    <strong>Total Price : <?php echo e($order->totalamnt); ?></strong>
                </div>    
            </div>

        </div>
    </div>


</div>

<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?> 





<?php if($oldorders->count()>0): ?>
<div class="container" style="margin-top: 50px; margin-bottom: 25px" >
<div class="row">
        <div class="col-md-10 col-md-offset-2">

            <h2 class="mb-50" style="margin-bottom: 50px">My Previous Orders </h2>

            <div class="panel panel-default">
                
                    


<?php $__currentLoopData = $oldorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="panel-body mb-3" >
<h4>Chef <?php echo e($ord->name); ?></h4>
<ul class="list-group">
         <li class="list-group-item">
         <span>OrderNum  #<?php echo e($ord->id); ?></span>
         <span class="ml-5"><?php echo e(date($ord->created_at)); ?></span>
         <span class="pull-right"> <strong>Total Price : <?php echo e($ord->totalamnt); ?></strong> </span>
         
         </li>
</ul>

  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
            </div>

        </div>
    </div>


</div>
<?php endif; ?>

</div>

<div class="col-md-4" style="float: right;">

        

<a class="btn btn-primary btn-lg" href="/mapslocation">
Click here to find the route    
</a>        
<div style="width: 400px">
    <a href="/mapslocation">
        <img src="../images/maps.jpg" alt="" width="100%"></a>
</div>
        
</div>

</div>


</div>

<script src="https://unpkg.com/ionicons@4.1.2/dist/ionicons.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


<!-- Fonts -->
<link rel="dns-prefetch" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

<!-- Styles -->
<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<script src="https://www.gstatic.com/firebasejs/5.0.4/firebase.js"></script>
<script>
// Initialize Firebase
var config = {
apiKey: "AIzaSyDlvh5ZOItKn1VTpdTWmndVObMtyi8WyS8",
authDomain: "ihearttakeout-578aa.firebaseapp.com",
databaseURL: "https://ihearttakeout-578aa.firebaseio.com",
projectId: "ihearttakeout-578aa",
storageBucket: "ihearttakeout-578aa.appspot.com",
messagingSenderId: "1026709201120"
};
firebase.initializeApp(config);
</script>

<script>
// $("#statusorder").text(123);
function writeUserData(userId, orid, chid , sta) {
firebase.database().ref('orders/' + orid).set({
userid: userId,
chefid: chid,
status: sta
});
}
var sts = firebase.database().ref('/orders/1');

sts.on('value',function(snapshot){
  console.log(snapshot.val());
  status = snapshot.val()['status'];
  $("#statusorder").text(status);
});

</script>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>