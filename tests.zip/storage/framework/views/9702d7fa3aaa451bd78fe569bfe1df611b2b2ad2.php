 

<?php echo e(csrf_field()); ?>

<div id="map-canvas" style="width:600px;height: 500px;" >

</div>

<script src="<?php echo e(asset('js/mapscript.js')); ?>" defer></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC_WSJDMq65r3I68pWo_qBhs4kOov7ab4k&libraries=places"  async defer></script>







<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>