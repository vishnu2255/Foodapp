<?php $__env->startComponent('mail::message'); ?>
# Introduction

**Your have successfully placed your order!!.**

<?php $__env->startComponent('mail::button', ['url' => 'http://127.0.0.1:8181/orders']); ?>
View Order
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
