<?php $__env->startSection('content'); ?>







  

<div class="col-md-11 order-md-2 mb-4" style="margin: 20px">
    <h4 class="d-flex justify-content-between align-items-center mb-3" style="text-align: center">
      
      Your Cart
       
    </h4>

    <a href="/dishes" class="btn btn-primary pull-right">      
    Click here to add more dishes 
    </a>
<?php $chefcnt=0;?>
    <?php $__currentLoopData = $chefcarts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php 
       $chefcnt++;
       $chefdet = explode('_',$key);
       $chefid = $chefdet[0];
       $chefname = $chefdet[1];
       $totsum = $chefdet[2];
?>
<div class="row" style="margin-top: 20px">
    <div class="col-md-12 col-sm-12">
            <h4 >
                    <a href="/chefs/<?php echo e($chefid); ?>" style="font-family: georgia,serif"> <b> <?php echo e($chefname); ?> </b> </a>    
            </h4>
    </div>

        
</div>
    

    <div class="row">

        <div class="col-md-7">

    <table class="table table-striped" style="margin: 20px">
        <thead>
          <tr>
            <th scope="col">SNo</th>
            <th scope="col">Product Name</th>
            <th scope="col">Quantity</th>
            <th scope="col">Price</th>
          </tr>
        </thead>
        <tbody >
          <?php $id=0; ?>
          <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <?php $id++;?>
          <th scope="row"><?php echo e($id); ?></th>
            <td>
                <h6 class="my-0" style="font-size: 25px;" > <strong> <?php echo e(strtoupper($cartitem->itm_name)); ?> </strong> </h6>
                <small class="text-muted" style="font-size: 15px;"> <?php echo e($cartitem->itm_desc); ?></small>
            </td>
            <td>
              
              
              
              

              <div class="input-group">
               
                    <button type="button"  class="mr-2 btn btn-primary btn-circle quantity-left-minus  btn-number" style="border-radius: 50%;" data-type="minus" data-field="">
                      
                      <ion-icon name="remove"></ion-icon>
                    </button>
           
                <input type="text" style="font-size: 20px; border: 2px ; text-align: center" id="<?php echo e($cartitem->menu_item_id.'_'.$cartitem->chef_id); ?>" class="btnquantitycart" value="<?php echo e($cartitem->qty); ?>"  name="quantity" style="width: 50px; text-align:center"  size="2" maxlength="2">
            
                    <button type="button" class="ml-2 btn btn-primary btn-circle quantity-right-plus  btn-number" style="border-radius: 50%;" data-type="plus" data-field="">
                        
                        <ion-icon name="add"></ion-icon>
                    </button>
              
            </div>


              
              
            </td>
            <td> <strong><span style="font-size: 30px;">  <?php echo e($cartitem->itm_price); ?> </span> </strong> </td>

            <td>
            <button type="button" style="border-radius: 50%;" id="rem_<?php echo e($cartitem->menu_item_id); ?>" class="btn btn-danger removebtn" aria-label="Left Align">
                <ion-icon name="close"></ion-icon>
             </button>
            </td>
          </tr>
          
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
         
        </tbody>
      </table>

                  
    </div>


<div class="col-md-4" id="drinks_<?php echo e($chefid); ?>" style="">
        
        <?php 
        // $drsec = $value[0]->drinks;
        // $dr = json_decode($drsec); 
        $did=0;           
        ?>

<table class="table table-hover" style="margin: 20px">
        <thead>
          <tr class="well-flat">
            
            <th scope="col">Drink</th>
            <th scope="col">Quantity</th>
            <th scope="col">Price</th>
          </tr>
        </thead>
        <tbody class="well-flat">

        <?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
        <?php  $did++; ?>

<td>

<div style="width:50px"> 
    <img src="../images/drinks/<?php echo e($drink->drnk_imagepath); ?>" alt="" srcset="" width="100%">
</div>
</td>
<td>




<div class="input-group">
               
    <button type="button"  class="mr-2 btn btn-primary btn-circle drnksleft" style="border-radius: 50%;" data-type="minus" data-field="">
      
      <ion-icon name="remove"></ion-icon>
    </button>
<?php if(Session::has('drnkssum')): ?>
  <input type="text" style="font-size: 20px; border: 2px ; text-align: center" id="<?php echo e($drink->id); ?>" class="drnkscart" value="<?php echo e($drink->drnkqty==NULL?0:$drink->drnkqty); ?>"  name="quantity" style="width: 50px; text-align:center"  size="2" maxlength="2">
<?php else: ?>
  <input type="text" style="font-size: 20px; border: 2px ; text-align: center" id="<?php echo e($drink->id); ?>" class="drnkscart" value="0"  name="quantity" style="width: 50px; text-align:center"  size="2" maxlength="2">
<?php endif; ?>
    <button type="button" class="ml-2 btn btn-primary btn-circle drnksryt" style="border-radius: 50%;" data-type="plus" data-field="">
        
        <ion-icon name="add"></ion-icon>
    </button>

</div>

</td>


<td>  <strong><span style="font-size: 30px;"> <?php echo e($drink->drnk_price); ?> </span> </strong> </td>

</tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
        </tbody>
</table>

<button id="savedrinks" class="ml-3 btn btn-danger savedrinks"> 
    Add To Cart
</button>

</div>
</div>
      <div class="row" style="margin: 20px">
          <div class="col-md-4">
                <a href="/checkout/<?php echo e($chefid); ?>"  class="btn btn-danger btn-lg" style="float: left;" id="checkout_<?php echo e($chefid); ?>" >Proceed to Checkout</a>            
          </div>
    
          
          <div class="col-md-2" style="float:right; color:red ">
              <strong>  <span style="font-size: 30px;" class="well-flat"><strong> Total:  </strong> </span> <span class="well-flat" style="font-size: 30px;"> $</span> <span style="font-size: 30px;" id="tot_val"> <?php echo e($totsum); ?>  </span>   
              </strong>
          </div>


         
      </div>

    
   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>



  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>